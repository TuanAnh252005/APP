# Ma trận phân quyền Phase 1

| Quyền | Ghi cân | Kế toán | Kho | Quản lý | Admin |
|---|---:|---:|---:|---:|---:|
| Xem khách | ✓ | ✓ | ✓ | ✓ | ✓ |
| Tạo/cập nhật khách | ✓ |  |  | ✓ | ✓ |
| Xem STK khách | ✓ | ✓ |  | ✓ | ✓ |
| Tạo phiếu cân | ✓ |  |  | ✓ | ✓ |
| Nhập mã cân | ✓ |  |  | ✓ | ✓ |
| Sửa mã cân khi chưa chốt | ✓ |  |  | ✓ | ✓ |
| Chốt cân | ✓ |  |  | ✓ | ✓ |
| Xem đơn giá |  | ✓ |  | ✓ | ✓ |
| Nhập đơn giá |  | ✓ |  | ✓ | ✓ |
| Chốt biên nhận |  | ✓ |  | ✓ | ✓ |
| Mở lại phiếu đã chốt |  |  |  | ✓ | ✓ |
| Duyệt yêu cầu sửa |  |  |  | ✓ | ✓ |
| Xem audit log |  |  |  | ✓ | ✓ |
| Quản lý user/role |  |  |  |  | ✓ |

> Quyền luôn được kiểm tra ở server/API, không chỉ ẩn nút trên giao diện.
