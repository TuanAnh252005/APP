-- NSTN Phase 2A - PostgreSQL Schema V1
-- Module: Nhap hang + Ghi can + Bien nhan thu mua
-- Target: PostgreSQL 15+

CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$ BEGIN CREATE TYPE source_type AS ENUM ('TRADER', 'COLLECTION_POINT'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE transaction_status AS ENUM ('OPEN', 'CLOSED', 'CANCELLED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE receipt_status AS ENUM ('DRAFT', 'WEIGHING', 'WEIGHED', 'WAITING_PRICE', 'PRICED', 'FINALIZED', 'CANCELLED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE weigh_session_status AS ENUM ('OPEN', 'COMPLETED', 'LOCKED', 'ARCHIVED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE weigh_input_method AS ENUM ('MANUAL', 'SCALE', 'IMPORT'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE settlement_status AS ENUM ('WAITING_PRICE', 'DRAFT', 'PRICED', 'FINALIZED', 'CANCELLED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE change_request_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'COMPLETED', 'CANCELLED'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS warehouses (
    warehouse_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    warehouse_code VARCHAR(30) NOT NULL UNIQUE,
    warehouse_name VARCHAR(150) NOT NULL,
    address TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS roles (
    role_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_code VARCHAR(50) NOT NULL UNIQUE,
    role_name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS permissions (
    permission_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    permission_code VARCHAR(100) NOT NULL UNIQUE,
    permission_name VARCHAR(150) NOT NULL,
    module_code VARCHAR(50) NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS user_roles (
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    role_id UUID NOT NULL REFERENCES roles(role_id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id UUID NOT NULL REFERENCES roles(role_id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES permissions(permission_id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE IF NOT EXISTS user_warehouses (
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    warehouse_id UUID NOT NULL REFERENCES warehouses(warehouse_id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, warehouse_id)
);

CREATE TABLE IF NOT EXISTS document_sequences (
    document_type VARCHAR(20) NOT NULL,
    warehouse_id UUID NOT NULL REFERENCES warehouses(warehouse_id),
    business_date DATE NOT NULL,
    current_value INTEGER NOT NULL DEFAULT 0 CHECK (current_value >= 0),
    PRIMARY KEY (document_type, warehouse_id, business_date)
);

CREATE TABLE IF NOT EXISTS customers (
    customer_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_code VARCHAR(30) NOT NULL UNIQUE,
    customer_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    cccd VARCHAR(20),
    address TEXT,
    area VARCHAR(200),
    note TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_customers_cccd_nonempty ON customers (cccd) WHERE cccd IS NOT NULL AND btrim(cccd) <> '';
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);
CREATE INDEX IF NOT EXISTS idx_customers_name_lower ON customers((lower(customer_name)));

CREATE TABLE IF NOT EXISTS customer_bank_accounts (
    bank_account_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(customer_id) ON DELETE CASCADE,
    bank_name VARCHAR(100) NOT NULL,
    account_number VARCHAR(50) NOT NULL,
    account_holder VARCHAR(150) NOT NULL,
    branch_name VARCHAR(150),
    is_default BOOLEAN NOT NULL DEFAULT FALSE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (customer_id, bank_name, account_number)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_customer_default_bank ON customer_bank_accounts(customer_id) WHERE is_default = TRUE AND is_active = TRUE;

CREATE TABLE IF NOT EXISTS collection_points (
    collection_point_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    point_code VARCHAR(30) NOT NULL UNIQUE,
    point_name VARCHAR(150) NOT NULL,
    area VARCHAR(200),
    address TEXT,
    warehouse_id UUID REFERENCES warehouses(warehouse_id),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS product_varieties (
    variety_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    variety_code VARCHAR(30) NOT NULL UNIQUE,
    variety_name VARCHAR(100) NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS product_classes (
    class_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    class_code VARCHAR(30) NOT NULL UNIQUE,
    class_name VARCHAR(100) NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS product_grades (
    grade_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    grade_code VARCHAR(30) NOT NULL UNIQUE,
    grade_name VARCHAR(100) NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS product_skus (
    sku_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku_code VARCHAR(60) NOT NULL UNIQUE,
    variety_id UUID NOT NULL REFERENCES product_varieties(variety_id),
    class_id UUID REFERENCES product_classes(class_id),
    grade_id UUID REFERENCES product_grades(grade_id),
    display_name VARCHAR(150) NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (variety_id, class_id, grade_id)
);
CREATE INDEX IF NOT EXISTS idx_product_skus_lookup ON product_skus(variety_id, class_id, grade_id);

CREATE TABLE IF NOT EXISTS business_transactions (
    transaction_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_code VARCHAR(40) NOT NULL UNIQUE,
    warehouse_id UUID NOT NULL REFERENCES warehouses(warehouse_id),
    source_type source_type NOT NULL,
    status transaction_status NOT NULL DEFAULT 'OPEN',
    created_by UUID NOT NULL REFERENCES users(user_id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ,
    note TEXT
);

CREATE TABLE IF NOT EXISTS inbound_receipts (
    receipt_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id UUID NOT NULL UNIQUE REFERENCES business_transactions(transaction_id),
    receipt_code VARCHAR(40) NOT NULL UNIQUE,
    toa_no VARCHAR(20),
    warehouse_id UUID NOT NULL REFERENCES warehouses(warehouse_id),
    source_type source_type NOT NULL,
    customer_id UUID REFERENCES customers(customer_id),
    collection_point_id UUID REFERENCES collection_points(collection_point_id),
    lot_date DATE NOT NULL,
    warehouse_date DATE NOT NULL,
    weigh_started_at TIMESTAMPTZ,
    weigh_completed_at TIMESTAMPTZ,
    driver_name VARCHAR(150),
    vehicle_plate VARCHAR(30),
    status receipt_status NOT NULL DEFAULT 'DRAFT',
    total_received_kg NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (total_received_kg >= 0),
    note TEXT,
    created_by UUID NOT NULL REFERENCES users(user_id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    CHECK (lot_date <= warehouse_date),
    CHECK ((source_type = 'TRADER' AND customer_id IS NOT NULL AND collection_point_id IS NULL) OR (source_type = 'COLLECTION_POINT' AND collection_point_id IS NOT NULL AND customer_id IS NULL))
);
CREATE INDEX IF NOT EXISTS idx_inbound_receipts_lot_date ON inbound_receipts(lot_date);
CREATE INDEX IF NOT EXISTS idx_inbound_receipts_warehouse_date ON inbound_receipts(warehouse_date);
CREATE INDEX IF NOT EXISTS idx_inbound_receipts_customer ON inbound_receipts(customer_id);
CREATE INDEX IF NOT EXISTS idx_inbound_receipts_point ON inbound_receipts(collection_point_id);
CREATE INDEX IF NOT EXISTS idx_inbound_receipts_warehouse_status ON inbound_receipts(warehouse_id, status);
CREATE INDEX IF NOT EXISTS idx_inbound_receipts_toa_date ON inbound_receipts(warehouse_id, warehouse_date, toa_no);

CREATE TABLE IF NOT EXISTS inbound_receipt_snapshots (
    snapshot_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    receipt_id UUID NOT NULL UNIQUE REFERENCES inbound_receipts(receipt_id) ON DELETE CASCADE,
    customer_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    cccd VARCHAR(20),
    address TEXT,
    area VARCHAR(200),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS receipt_items (
    receipt_item_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    receipt_id UUID NOT NULL REFERENCES inbound_receipts(receipt_id) ON DELETE CASCADE,
    sku_id UUID NOT NULL REFERENCES product_skus(sku_id),
    origin_quantity_kg NUMERIC(14,2),
    received_quantity_kg NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (received_quantity_kg >= 0),
    transport_loss_kg NUMERIC(14,2) NOT NULL DEFAULT 0,
    transport_loss_pct NUMERIC(9,4) NOT NULL DEFAULT 0,
    sequence_no INTEGER NOT NULL DEFAULT 1 CHECK (sequence_no > 0),
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (receipt_id, sku_id),
    CHECK (origin_quantity_kg IS NULL OR origin_quantity_kg >= 0)
);
CREATE INDEX IF NOT EXISTS idx_receipt_items_receipt ON receipt_items(receipt_id);
CREATE INDEX IF NOT EXISTS idx_receipt_items_sku ON receipt_items(sku_id);

CREATE TABLE IF NOT EXISTS weigh_sessions (
    weigh_session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    receipt_id UUID NOT NULL REFERENCES inbound_receipts(receipt_id) ON DELETE CASCADE,
    operator_id UUID NOT NULL REFERENCES users(user_id),
    status weigh_session_status NOT NULL DEFAULT 'OPEN',
    terminal_id VARCHAR(80),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    note TEXT
);
CREATE INDEX IF NOT EXISTS idx_weigh_sessions_receipt ON weigh_sessions(receipt_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_open_weigh_session_per_receipt ON weigh_sessions(receipt_id) WHERE status = 'OPEN';

CREATE TABLE IF NOT EXISTS weigh_details (
    weigh_detail_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    weigh_session_id UUID NOT NULL REFERENCES weigh_sessions(weigh_session_id) ON DELETE CASCADE,
    receipt_item_id UUID NOT NULL REFERENCES receipt_items(receipt_item_id) ON DELETE CASCADE,
    sequence_no INTEGER NOT NULL CHECK (sequence_no > 0),
    client_mutation_id UUID NOT NULL DEFAULT gen_random_uuid(),
    weight_kg NUMERIC(10,2) NOT NULL CHECK (weight_kg > 0),
    input_method weigh_input_method NOT NULL DEFAULT 'MANUAL',
    recorded_by UUID NOT NULL REFERENCES users(user_id),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    retention_until DATE NOT NULL DEFAULT (CURRENT_DATE + 7),
    archived_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    UNIQUE (weigh_session_id, receipt_item_id, sequence_no),
    UNIQUE (client_mutation_id)
);
CREATE INDEX IF NOT EXISTS idx_weigh_details_item ON weigh_details(receipt_item_id);
CREATE INDEX IF NOT EXISTS idx_weigh_details_session ON weigh_details(weigh_session_id);
CREATE INDEX IF NOT EXISTS idx_weigh_details_retention ON weigh_details(retention_until) WHERE archived_at IS NULL;

CREATE TABLE IF NOT EXISTS purchase_settlements (
    settlement_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    settlement_code VARCHAR(40) NOT NULL UNIQUE,
    receipt_id UUID NOT NULL UNIQUE REFERENCES inbound_receipts(receipt_id),
    customer_id UUID NOT NULL REFERENCES customers(customer_id),
    bank_account_id UUID REFERENCES customer_bank_accounts(bank_account_id),
    status settlement_status NOT NULL DEFAULT 'WAITING_PRICE',
    total_quantity_kg NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (total_quantity_kg >= 0),
    total_amount NUMERIC(20,0) NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
    amount_in_words TEXT,
    accountant_id UUID REFERENCES users(user_id),
    settlement_date DATE NOT NULL DEFAULT CURRENT_DATE,
    priced_at TIMESTAMPTZ,
    finalized_at TIMESTAMPTZ,
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_purchase_settlements_status ON purchase_settlements(status);
CREATE INDEX IF NOT EXISTS idx_purchase_settlements_customer ON purchase_settlements(customer_id);
CREATE INDEX IF NOT EXISTS idx_purchase_settlements_date ON purchase_settlements(settlement_date);

CREATE TABLE IF NOT EXISTS purchase_settlement_customer_snapshots (
    settlement_id UUID PRIMARY KEY REFERENCES purchase_settlements(settlement_id) ON DELETE CASCADE,
    customer_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    cccd VARCHAR(20),
    address TEXT,
    area VARCHAR(200),
    bank_name VARCHAR(100),
    account_number VARCHAR(50),
    account_holder VARCHAR(150),
    bank_branch_name VARCHAR(150),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS purchase_settlement_lines (
    settlement_line_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    settlement_id UUID NOT NULL REFERENCES purchase_settlements(settlement_id) ON DELETE CASCADE,
    receipt_item_id UUID NOT NULL REFERENCES receipt_items(receipt_item_id),
    sku_code_snapshot VARCHAR(60) NOT NULL,
    item_name_snapshot VARCHAR(150) NOT NULL,
    quantity_kg_snapshot NUMERIC(14,2) NOT NULL CHECK (quantity_kg_snapshot >= 0),
    unit_price NUMERIC(18,0) CHECK (unit_price IS NULL OR unit_price >= 0),
    line_amount NUMERIC(20,0) NOT NULL DEFAULT 0 CHECK (line_amount >= 0),
    sequence_no INTEGER NOT NULL DEFAULT 1 CHECK (sequence_no > 0),
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (settlement_id, receipt_item_id)
);
CREATE INDEX IF NOT EXISTS idx_settlement_lines_settlement ON purchase_settlement_lines(settlement_id);

CREATE TABLE IF NOT EXISTS document_change_requests (
    request_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_type VARCHAR(50) NOT NULL,
    document_id UUID NOT NULL,
    request_type VARCHAR(50) NOT NULL,
    requested_by UUID NOT NULL REFERENCES users(user_id),
    reason TEXT NOT NULL,
    status change_request_status NOT NULL DEFAULT 'PENDING',
    approved_by UUID REFERENCES users(user_id),
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    resolution_note TEXT
);
CREATE INDEX IF NOT EXISTS idx_change_requests_document ON document_change_requests(document_type, document_id);
CREATE INDEX IF NOT EXISTS idx_change_requests_status ON document_change_requests(status);

CREATE TABLE IF NOT EXISTS audit_logs (
    audit_id BIGSERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(user_id),
    warehouse_id UUID REFERENCES warehouses(warehouse_id),
    action VARCHAR(80) NOT NULL,
    entity_type VARCHAR(80) NOT NULL,
    entity_id VARCHAR(100),
    old_value JSONB,
    new_value JSONB,
    reason TEXT,
    ip_address VARCHAR(64),
    device_info TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id, created_at DESC);

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER LANGUAGE plpgsql AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END $$;

DO $$ BEGIN CREATE TRIGGER trg_warehouses_updated_at BEFORE UPDATE ON warehouses FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_customers_updated_at BEFORE UPDATE ON customers FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_customer_bank_updated_at BEFORE UPDATE ON customer_bank_accounts FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_collection_points_updated_at BEFORE UPDATE ON collection_points FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_product_skus_updated_at BEFORE UPDATE ON product_skus FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_inbound_receipts_updated_at BEFORE UPDATE ON inbound_receipts FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_receipt_items_updated_at BEFORE UPDATE ON receipt_items FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_purchase_settlements_updated_at BEFORE UPDATE ON purchase_settlements FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TRIGGER trg_settlement_lines_updated_at BEFORE UPDATE ON purchase_settlement_lines FOR EACH ROW EXECUTE FUNCTION set_updated_at(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION calc_receipt_item_transport_loss() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.origin_quantity_kg IS NULL OR NEW.origin_quantity_kg = 0 THEN
        NEW.transport_loss_kg := 0; NEW.transport_loss_pct := 0;
    ELSE
        NEW.transport_loss_kg := ROUND(NEW.origin_quantity_kg - NEW.received_quantity_kg, 2);
        NEW.transport_loss_pct := ROUND(((NEW.origin_quantity_kg - NEW.received_quantity_kg) / NEW.origin_quantity_kg) * 100, 4);
    END IF;
    RETURN NEW;
END $$;
DO $$ BEGIN CREATE TRIGGER trg_calc_receipt_item_transport_loss BEFORE INSERT OR UPDATE OF origin_quantity_kg, received_quantity_kg ON receipt_items FOR EACH ROW EXECUTE FUNCTION calc_receipt_item_transport_loss(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION refresh_receipt_total() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE v_receipt_id UUID;
BEGIN
    IF TG_OP = 'DELETE' THEN v_receipt_id := OLD.receipt_id; ELSE v_receipt_id := NEW.receipt_id; END IF;
    UPDATE inbound_receipts r
    SET total_received_kg = COALESCE((SELECT ROUND(SUM(ri.received_quantity_kg), 2) FROM receipt_items ri WHERE ri.receipt_id = v_receipt_id), 0)
    WHERE r.receipt_id = v_receipt_id;
    IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END $$;
DO $$ BEGIN CREATE TRIGGER trg_refresh_receipt_total AFTER INSERT OR UPDATE OR DELETE ON receipt_items FOR EACH ROW EXECUTE FUNCTION refresh_receipt_total(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION calc_settlement_line_amount() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.unit_price IS NULL THEN NEW.line_amount := 0; ELSE NEW.line_amount := ROUND(NEW.quantity_kg_snapshot * NEW.unit_price, 0); END IF;
    RETURN NEW;
END $$;
DO $$ BEGIN CREATE TRIGGER trg_calc_settlement_line_amount BEFORE INSERT OR UPDATE OF quantity_kg_snapshot, unit_price ON purchase_settlement_lines FOR EACH ROW EXECUTE FUNCTION calc_settlement_line_amount(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION refresh_settlement_totals() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE v_settlement_id UUID;
BEGIN
    IF TG_OP = 'DELETE' THEN v_settlement_id := OLD.settlement_id; ELSE v_settlement_id := NEW.settlement_id; END IF;
    UPDATE purchase_settlements s
    SET total_quantity_kg = COALESCE((SELECT ROUND(SUM(l.quantity_kg_snapshot), 2) FROM purchase_settlement_lines l WHERE l.settlement_id = v_settlement_id), 0),
        total_amount = COALESCE((SELECT SUM(l.line_amount) FROM purchase_settlement_lines l WHERE l.settlement_id = v_settlement_id), 0)
    WHERE s.settlement_id = v_settlement_id;
    IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END $$;
DO $$ BEGIN CREATE TRIGGER trg_refresh_settlement_totals AFTER INSERT OR UPDATE OR DELETE ON purchase_settlement_lines FOR EACH ROW EXECUTE FUNCTION refresh_settlement_totals(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION prevent_finalized_settlement_line_change() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE v_status settlement_status;
BEGIN
    SELECT status INTO v_status FROM purchase_settlements WHERE settlement_id = CASE WHEN TG_OP = 'DELETE' THEN OLD.settlement_id ELSE NEW.settlement_id END;
    IF v_status = 'FINALIZED' THEN RAISE EXCEPTION 'FINALIZED_SETTLEMENT_IS_IMMUTABLE'; END IF;
    IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END $$;
DO $$ BEGIN CREATE TRIGGER trg_prevent_finalized_line_update BEFORE UPDATE OR DELETE ON purchase_settlement_lines FOR EACH ROW EXECUTE FUNCTION prevent_finalized_settlement_line_change(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION prevent_finalized_settlement_line_insert() RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE v_status settlement_status;
BEGIN
    SELECT status INTO v_status FROM purchase_settlements WHERE settlement_id = NEW.settlement_id;
    IF v_status = 'FINALIZED' THEN RAISE EXCEPTION 'FINALIZED_SETTLEMENT_IS_IMMUTABLE'; END IF;
    RETURN NEW;
END $$;
DO $$ BEGIN CREATE TRIGGER trg_prevent_finalized_line_insert BEFORE INSERT ON purchase_settlement_lines FOR EACH ROW EXECUTE FUNCTION prevent_finalized_settlement_line_insert(); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION archive_expired_weigh_details() RETURNS INTEGER LANGUAGE plpgsql AS $$
DECLARE v_count INTEGER;
BEGIN
    UPDATE weigh_details SET archived_at = NOW()
    WHERE archived_at IS NULL AND deleted_at IS NULL AND retention_until < CURRENT_DATE;
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END $$;
