# NSTN Warehouse V1 — Kiến trúc đã triển khai

## Luồng dữ liệu

Nguồn hàng → Phiếu nhập → Ghi cân → Tổng sổ → Tồn hàng thô → (Bán / Chuyển kho / Gia công) → Đóng thùng → Thành phẩm.

Đối với thương lái, sau chốt cân hệ thống tạo Biên nhận thu mua để kế toán nhập đơn giá từng SKU. Đối với điểm thu, hệ thống so sánh kg tại điểm và kg thực cân ở kho để tính hao hụt vận chuyển.

## Nguyên tắc dữ liệu

- Một phiếu có không giới hạn SKU.
- Ngày lô và ngày nhập kho là hai trường riêng.
- Giao diện ghi cân 5 dòng/cột, database lưu từng mã cân riêng.
- Mã cân chi tiết hiển thị 7 ngày rồi được archive; tổng sổ giữ lâu dài.
- Tồn kho tính từ inventory movement ledger, không sửa tay số tồn.
- Gia công có thể nhận nhiều lô đầu vào và tạo nhiều SKU đầu ra.
- Kg thành phẩm là tổng cân thực từng thùng, không phải số thùng × định mức.
- Người ghi cân không được xem đơn giá/tiền.
- Kế toán không được sửa kg.
- Audit log ghi thao tác quan trọng.

## Runtime hiện tại

App chạy bằng Node.js 22 và SQLite/WAL, không cần cài package npm. Cấu trúc này phù hợp cho một máy chủ nội bộ hoặc VPS đơn. Khi triển khai nhiều server hoặc tải đồng thời lớn, chuyển database sang PostgreSQL theo schema trong `docs/postgresql_schema_phase2.sql`.
