# NSTN Phase 2A — Workflow nghiệp vụ đã khóa

## 1. Thương lái tại kho

`DRAFT → WEIGHING → WAITING_PRICE → PRICED → FINALIZED`

1. Nhân viên cân tạo phiếu cho khách.
2. Thêm không giới hạn SKU vào cùng một phiếu.
3. Mỗi mã cân được lưu riêng ở `weigh_details`; UI chỉ trình bày theo 5 dòng/cột.
4. Chốt cân:
   - tổng từng SKU ghi vào `receipt_items.received_quantity_kg`;
   - khóa phiên cân;
   - phiếu chuyển `WAITING_PRICE`;
   - số kg không còn được kế toán sửa.
5. Kế toán tạo biên nhận từ phiếu đã cân.
6. Hệ thống snapshot khách, STK, SKU, kg.
7. Kế toán chỉ nhập `unit_price` từng dòng.
8. Chốt biên nhận → `FINALIZED`, chứng từ bất biến.

## 2. Hàng điểm thu

`DRAFT → WEIGHING → WEIGHED`

- Có `origin_quantity_kg` tại điểm.
- Kho cân lại thành `received_quantity_kg`.
- Hệ thống tính:
  - `transport_loss_kg = origin - received`
  - `transport_loss_pct = (origin - received) / origin × 100`
- Không tự động đưa sang màn hình định giá của kế toán tại kho.

## 3. Ngày lô và ngày nhập kho

- `lot_date`: ngày phát sinh thu mua/lô.
- `warehouse_date`: ngày hàng thực tế nhập kho.
- Báo cáo bắt buộc cho phép chọn `LOT_DATE` hoặc `WAREHOUSE_DATE`.

## 4. Một lái nhiều loại hàng

Ví dụ cùng một phiếu:

- Thái A — 594,1 kg
- Thái B — 414,6 kg
- Thái C — 213,0 kg
- Thái Dạt — 43,5 kg
- Thái A Loại 2 — 178,7 kg

Không dùng các cột A/B/C cố định trong database. Mỗi dòng là một `receipt_item` tham chiếu `product_sku`.

## 5. Quy tắc sửa số cân

- Khi `WEIGHING`: nhân viên cân được sửa/xóa mã cân của phiên mình theo quyền.
- Sau khi chốt: nhân viên cân không được sửa trực tiếp.
- Kế toán tuyệt đối không sửa kg.
- Nếu sai: tạo `document_change_request` → quản lý duyệt → mở lại đúng chứng từ → audit log đầy đủ.

## 6. Chính sách 7 ngày

- `weigh_details`: chi tiết các mã 52,3; 52,7; 42,2…
- `receipt_items.received_quantity_kg`: tổng sổ chính thức, giữ lâu dài.
- Sau 7 ngày chi tiết cân được `archived_at`, không xóa ngay.
- Chỉ tài khoản có quyền phù hợp mới được xem archive khi cần đối soát.

## 7. Quy tắc bảo mật dữ liệu giá

Tài khoản `WEIGHER`:

- được xem tên khách, CCCD/SĐT, STK phục vụ phiếu;
- được nhập kg;
- không có quyền `price.view` hoặc `price.edit`;
- API không trả đơn giá/thành tiền nếu người dùng không có quyền.

Tài khoản `ACCOUNTANT`:

- xem tổng kg đã khóa;
- nhập giá;
- không có `weigh.detail.edit`.
