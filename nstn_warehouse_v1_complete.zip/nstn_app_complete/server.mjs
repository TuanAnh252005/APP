import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleApi } from './lib/api.mjs';
import { json, serveStatic } from './lib/http.mjs';
import './lib/db.mjs';

const ROOT=path.dirname(fileURLToPath(import.meta.url));
const PUBLIC=path.join(ROOT,'public');
const PORT=Number(process.env.PORT||4173);
const HOST=process.env.HOST||'0.0.0.0';

const server=http.createServer(async (req,res)=>{
  try{
    const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`);
    if(url.pathname.startsWith('/api/')) return await handleApi(req,res,url);
    if(serveStatic(res,PUBLIC,url.pathname)) return;
    // SPA fallback
    if(serveStatic(res,PUBLIC,'/index.html')) return;
    json(res,404,{error:'Not found'});
  }catch(e){
    console.error(e);
    const status=e.status||500;
    json(res,status,{error:status===500?'Lỗi hệ thống':e.message,code:e.code||'ERROR'});
  }
});
server.listen(PORT,HOST,()=>console.log(`NSTN Warehouse running at http://localhost:${PORT}`));
