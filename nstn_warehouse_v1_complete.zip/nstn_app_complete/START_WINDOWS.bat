@echo off
cd /d %~dp0
echo ==========================================
echo NSTN WAREHOUSE - KHOI DONG HE THONG
echo ==========================================
echo Mo trinh duyet tai: http://localhost:4173
echo De dung app, nhan Ctrl+C.
echo.
node --no-warnings server.mjs
pause
