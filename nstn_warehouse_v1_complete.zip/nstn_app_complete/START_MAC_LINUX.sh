#!/usr/bin/env sh
cd "$(dirname "$0")"
echo "NSTN Warehouse: http://localhost:4173"
node --no-warnings server.mjs
