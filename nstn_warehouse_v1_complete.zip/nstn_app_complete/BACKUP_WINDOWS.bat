@echo off
cd /d %~dp0
node --no-warnings scripts\backup-db.mjs
pause
