import fs from 'node:fs';import path from 'node:path';import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const src=path.join(root,'data','nstn.sqlite');
if(!fs.existsSync(src)){console.error('Chưa có database. Hãy chạy app trước.');process.exit(1)}
const dir=path.join(root,'backups');fs.mkdirSync(dir,{recursive:true});const stamp=new Date().toISOString().replaceAll(':','-').replace('T','_').slice(0,19);const dest=path.join(dir,`nstn_${stamp}.sqlite`);fs.copyFileSync(src,dest);console.log(`Đã sao lưu: ${dest}`);
