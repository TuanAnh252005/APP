import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const p=path.join(root,'data','nstn.sqlite');
for(const f of [p,p+'-wal',p+'-shm']){try{fs.rmSync(f,{force:true})}catch{}}
await import('../lib/db.mjs');
console.log('Đã tạo lại database và dữ liệu danh mục mặc định.');
