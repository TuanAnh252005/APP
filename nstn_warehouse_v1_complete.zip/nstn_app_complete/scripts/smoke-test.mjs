import { spawn } from 'node:child_process';import fs from 'node:fs';import path from 'node:path';import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const db=path.join(root,'data','smoke.sqlite');try{fs.rmSync(db,{force:true})}catch{}
const port=4199;const child=spawn(process.execPath,['--no-warnings','server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),NSTN_DB_PATH:db},stdio:['ignore','pipe','pipe']});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));let cookie='';
try{
 await sleep(700);const login=await fetch(`http://127.0.0.1:${port}/api/auth/login`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username:'admin',password:'Admin@123'})});if(!login.ok)throw new Error('login failed');cookie=login.headers.get('set-cookie').split(';')[0];const me=await login.json();const wh=me.user.warehouses[0].warehouse_id;
 const dash=await fetch(`http://127.0.0.1:${port}/api/dashboard?warehouseId=${wh}`,{headers:{cookie}});if(!dash.ok)throw new Error('dashboard failed');
 const skus=await fetch(`http://127.0.0.1:${port}/api/product-skus`,{headers:{cookie}}).then(r=>r.json());if(!skus.length)throw new Error('sku seed failed');
 console.log('SMOKE TEST OK: auth, RBAC, dashboard, product catalog.');
}finally{child.kill();await sleep(100);try{fs.rmSync(db,{force:true});fs.rmSync(db+'-wal',{force:true});fs.rmSync(db+'-shm',{force:true})}catch{}}
