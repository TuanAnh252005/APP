import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const db=path.join(root,'data','e2e.sqlite');
for(const f of [db,db+'-wal',db+'-shm'])try{fs.rmSync(f,{force:true})}catch{}
const port=4200; const base=`http://127.0.0.1:${port}`;
const child=spawn(process.execPath,['--no-warnings','server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),NSTN_DB_PATH:db},stdio:['ignore','pipe','pipe']});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));let cookie='';
async function req(p,opt={}){const r=await fetch(base+p,{...opt,headers:{'content-type':'application/json',cookie,...(opt.headers||{})}});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(`${r.status} ${p}: ${j.error||JSON.stringify(j)}`);return j}
try{
 await sleep(800);
 let r=await fetch(base+'/api/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username:'admin',password:'Admin@123'})});assert.equal(r.status,200);cookie=r.headers.get('set-cookie').split(';')[0];const login=await r.json();const wh=login.user.warehouses[0].warehouse_id;
 const customers=await req('/api/customers');const cust=customers[0];const bank=cust.bank_accounts[0];const skus=await req('/api/product-skus');const skuA=skus.find(x=>x.sku_code==='THAI-VIP-A');const skuB=skus.find(x=>x.sku_code==='THAI-VIP-B');assert.ok(skuA&&skuB);
 const receipt=await req('/api/receipts',{method:'POST',body:JSON.stringify({warehouseId:wh,sourceType:'TRADER',customerId:cust.customer_id,bankAccountId:bank.bank_account_id,toaNo:'E2E',lotDate:'2026-10-06',warehouseDate:'2026-10-06'})});
 const itemA=await req(`/api/receipts/${receipt.receipt_id}/items`,{method:'POST',body:JSON.stringify({skuId:skuA.sku_id})});
 const itemB=await req(`/api/receipts/${receipt.receipt_id}/items`,{method:'POST',body:JSON.stringify({skuId:skuB.sku_id})});
 const session=await req(`/api/receipts/${receipt.receipt_id}/start-weighing`,{method:'POST',body:'{}'});
 for(const [item,weights] of [[itemA,[50.2,49.8]],[itemB,[40.0,35.0]]])for(const w of weights)await req(`/api/weigh-sessions/${session.weigh_session_id}/weights`,{method:'POST',body:JSON.stringify({receiptItemId:item.receipt_item_id,weightKg:w,clientMutationId:crypto.randomUUID()})});
 const closed=await req(`/api/receipts/${receipt.receipt_id}/complete-weighing`,{method:'POST'});assert.equal(Number(closed.total_received_kg),175);assert.equal(closed.status,'WAITING_PRICE');
 const sid=closed.settlement.settlement_id;let sd=await req(`/api/settlements/${sid}`);assert.equal(sd.lines.length,2);sd=await req(`/api/settlements/${sid}/lines`,{method:'PUT',body:JSON.stringify({lines:sd.lines.map((x,i)=>({lineId:x.settlement_line_id,unitPrice:i?65000:85000}))})});assert.equal(sd.status,'PRICED');sd=await req(`/api/settlements/${sid}/finalize`,{method:'POST'});assert.equal(sd.status,'FINALIZED');assert.ok(sd.total_amount>0);
 const stock=await req(`/api/inventory/stock?warehouseId=${wh}`);assert.equal(Math.round(stock.reduce((a,x)=>a+Number(x.available_kg),0)*10)/10,175);
 const source=stock.find(x=>x.sku_code==='THAI-VIP-A');const batch=await req('/api/processing-batches',{method:'POST',body:JSON.stringify({warehouseId:wh,processingDate:'2026-10-06',inputs:[{receiptItemId:source.receipt_item_id,quantityKg:60}]})});assert.equal(Number(batch.input_total_kg),60);
 const meta=await req('/api/packing-meta');const ps=await req(`/api/processing-batches/${batch.batch_id}/packing-sessions`,{method:'POST',body:JSON.stringify({skuId:skuA.sku_id,brandId:meta.brands[0].brand_id,strapSpecId:meta.strapSpecs[0].strap_spec_id})});
 for(const w of [10.1,10.2,10.0,9.9,10.0])await req(`/api/packing-sessions/${ps.packing_session_id}/units`,{method:'POST',body:JSON.stringify({weightKg:w,fruitCount:4})});
 const done=await req(`/api/processing-batches/${batch.batch_id}/complete`,{method:'POST'});assert.equal(done.status,'COMPLETED');assert.equal(Number(done.output_total_kg),50.2);assert.equal(Math.round(Number(done.loss_kg)*10)/10,9.8);
 const fg=await req(`/api/finished-goods?warehouseId=${wh}`);assert.ok(fg.some(x=>x.batch_id===batch.batch_id&&x.box_count===5));
 console.log('E2E TEST OK: receipt → multi-SKU weighing → settlement → inventory → processing → packing → finished goods.');
} finally {
 child.kill();await sleep(150);for(const f of [db,db+'-wal',db+'-shm'])try{fs.rmSync(f,{force:true})}catch{}
}
