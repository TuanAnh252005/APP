# NSTN Warehouse — App quản lý kho sầu riêng V1

App chạy thật gồm: đăng nhập/RBAC, khách hàng & STK, phiếu nhập, ghi cân 5 dòng/cột, hàng điểm thu & hao hụt vận chuyển, biên nhận thu mua/kế toán, tồn kho theo lô, bán hàng thô, chuyển kho, gia công, đóng thùng, thành phẩm, báo cáo theo ngày/lô, audit log và lưu trữ mã cân sau 7 ngày.

## Chạy trên Windows

1. Cài **Node.js 22 LTS hoặc mới hơn**.
2. Giải nén thư mục này.
3. Nhấp đúp `START_WINDOWS.bat`.
4. Mở trình duyệt: `http://localhost:4173`

Không cần `npm install` và không cần Internet.

## Tài khoản mặc định

| Vai trò | User | Password |
|---|---|---|
| Quản trị | `admin` | `Admin@123` |
| Quản lý | `quanly` | `Ql@123` |
| Ghi cân | `can` | `Can@123` |
| Kế toán | `ketoan` | `Kt@123` |
| Nhân viên kho | `kho` | `Kho@123` |
| Gia công/đóng hàng | `giacong` | `Gc@123` |

**Đổi mật khẩu mặc định ngay khi triển khai thật.** Admin có màn hình `Tài khoản & phân quyền` để tạo/khóa tài khoản và đổi vai trò.

## Dữ liệu

Database nằm tại `data/nstn.sqlite`. Hãy sao lưu file này hằng ngày. Có thể chạy `BACKUP_WINDOWS.bat` để tạo bản sao trong thư mục `backups/`.

Chi tiết mã cân (các số 52.3, 52.7...) có `retention_until = 7 ngày`. Sau thời hạn, hệ thống archive và giao diện nghiệp vụ không hiển thị nữa; tổng kg từng mặt hàng và chứng từ vẫn giữ nguyên.

## Nghiệp vụ đã khóa

- Một lái có nhiều loại hàng trong cùng một phiếu.
- Đội cân chỉ nhập kg và thông tin khách; không có quyền giá/tiền.
- Kế toán nhận tổng kg đã khóa và chỉ nhập đơn giá theo từng SKU.
- Hàng điểm thu có `kg tại điểm` và `kg tại kho`, hệ thống tự tính hao hụt vận chuyển.
- Tồn kho theo `lô × SKU × nguồn phiếu` được tính bằng movement ledger.
- Có thể phân bổ tồn sang bán hàng, chuyển kho hoặc gia công.
- Mẻ gia công có thể lấy từ nhiều lô; đầu ra có thể đổi hạng so với đầu vào.
- Đóng thùng lưu thương hiệu, quy cách dây đai, số trái/thùng và kg cân thực từng thùng.
- Hao hụt gia công = đầu vào − tổng kg thành phẩm đóng ra.

## Lệnh kỹ thuật

```bash
npm start
npm run dev
npm run reset
node --no-warnings scripts/backup-db.mjs
node --no-warnings scripts/smoke-test.mjs
```

## Triển khai mạng nội bộ

Chạy app trên một máy trong kho, sau đó các máy/điện thoại cùng mạng truy cập `http://IP-MAY-CHU:4173`. Firewall của máy chủ cần cho phép cổng 4173.

## Nâng cấp production

Runtime SQLite hiện tại là bản V1 tự chứa, phù hợp để nghiệm thu nghiệp vụ và chạy nội bộ trên một server. Nếu đưa lên cloud và có nhiều kho/người dùng đồng thời ở quy mô lớn, nên dùng PostgreSQL; schema nền đã kèm trong `docs/postgresql_schema_phase2.sql`.
